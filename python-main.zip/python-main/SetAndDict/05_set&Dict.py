#Write a Python program to find the union and intersection of two sets
set1 = {1, 2, 3, 4, 5}
set2 = {4, 5, 6, 7, 8}

union = set1.union(set2)
intersection = set1.intersection(set2)

print("Union:", union)
print("Intersection:", intersection)