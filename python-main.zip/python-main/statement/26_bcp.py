# Write a program to stop a loop when the number 5 is reached using break
for i in range(1, 11):
    if i == 5:
        break
    print(i)