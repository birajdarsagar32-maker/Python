#Write a program to check whether a number is divisible by 5
number = int(input("Enter a number: "))
if number % 5 == 0:
    print("The number is divisible by 5.")
else:
    print("The number is not divisible by 5.")